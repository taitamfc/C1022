<?php
namespace App;
class MayTinh {
    public function sum($a,$b){

    }
}